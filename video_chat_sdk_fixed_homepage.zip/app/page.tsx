export default function Home() {
  return (
    <main className="flex items-center justify-center min-h-screen text-white bg-black">
      <h1 className="text-3xl font-bold">ChatChill is Live 🎉</h1>
      <p className="mt-4">100ms SDK is pre-integrated. Customize UI freely.</p>
    </main>
  );
}